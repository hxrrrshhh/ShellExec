#!/bin/bash
hostname

