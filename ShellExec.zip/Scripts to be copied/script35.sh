#!/bin/bash
who

