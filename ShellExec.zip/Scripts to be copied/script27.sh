#!/bin/bash
df -ih

