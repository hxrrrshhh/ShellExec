#!/bin/bash
find /home/hxrrrshhh/ -type l

