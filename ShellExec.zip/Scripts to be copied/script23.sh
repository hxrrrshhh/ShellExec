#!/bin/bash
ip a | grep inet

