#!/bin/bash
nslookup google.com

