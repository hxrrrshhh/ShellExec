#!/bin/bash
uname -m

