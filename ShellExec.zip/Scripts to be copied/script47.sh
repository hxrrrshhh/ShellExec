#!/bin/bash
find /home/hxrrrshhh/ -type d | wc -l

