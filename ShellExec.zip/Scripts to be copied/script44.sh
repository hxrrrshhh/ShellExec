#!/bin/bash
lscpu

