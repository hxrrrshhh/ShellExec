#!/bin/bash
last -n 10

