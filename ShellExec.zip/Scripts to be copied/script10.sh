#!/bin/bash
ps aux --sort=-%mem | head

