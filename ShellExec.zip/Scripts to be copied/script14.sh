#!/bin/bash
ls /home/hxrrrshhh/

