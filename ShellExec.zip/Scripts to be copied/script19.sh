#!/bin/bash
grep -i "error" /var/log/*log

