#!/bin/bash
ss -tuln

