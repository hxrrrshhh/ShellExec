#!/bin/bash
ping -c 4 google.com

