#!/bin/bash
cut -d: -f1 /etc/group

