#!/bin/bash
find /home/hxrrrshhh/ -type f -size +100M

