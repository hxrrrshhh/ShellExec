#!/bin/bash
uptime

