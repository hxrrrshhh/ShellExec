#!/bin/bash
du -sh /home/hxrrrshhh/

