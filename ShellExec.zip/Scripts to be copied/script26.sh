#!/bin/bash
df -h

