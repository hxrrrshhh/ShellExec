#!/bin/bash
ps aux --sort=-%cpu | head

