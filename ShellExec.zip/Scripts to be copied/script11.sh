#!/bin/bash
ps aux

