#!/bin/bash
tail -n 10 /var/log/syslog

