#!/bin/bash
lsmod

