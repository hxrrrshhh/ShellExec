#!/bin/bash
find /home/hxrrrshhh/ -type f -empty

