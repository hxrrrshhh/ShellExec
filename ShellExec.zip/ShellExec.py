import tkinter
import customtkinter as ctk
from PIL import ImageTk, Image
import tkinter.messagebox as messagebox
import paramiko
import json
import os

class SSHApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ShellExec")
        self.root.geometry("1280x720")

        # Set appearance mode and color theme
        ctk.set_appearance_mode("System")  # Modes: "System" (standard), "Dark", "Light"
        ctk.set_default_color_theme("C:/Users/Hxrrrsshhh/Desktop/ShellExec/themes/violet.json")  # Custom theme

        # Initialize the SSH client
        self.ssh = None

        # Create frames
        self.login_frame = ctk.CTkFrame(self.root)
        self.main_frame = ctk.CTkFrame(self.root)

        self.create_toggle_button()  # Create the toggle button
        self.create_login_page()
        self.create_main_page()

        # Load saved credentials
        self.load_credentials()

        # Show login frame by default
        self.login_frame.pack(fill="both", expand=True)

    def create_toggle_button(self):
        """Create the appearance mode toggle button."""
        self.toggle_button = ctk.CTkButton(
            self.root,
            text="Toggle Light/Dark Mode",
            command=self.toggle_appearance_mode,
            font=("Super Shiny", 14)
        )
        self.toggle_button.pack(side="top", anchor="ne", padx=10, pady=10)  # Position at top right

    def toggle_appearance_mode(self):
        """Toggle between light and dark mode."""
        current_mode = ctk.get_appearance_mode()
        new_mode = "Dark" if current_mode == "Light" else "Light"
        ctk.set_appearance_mode(new_mode)

    def create_login_page(self):
        """Create the login page."""
        # Load background image
        img1 = Image.open(r"C:\Users\Hxrrrsshhh\Desktop\ShellExec\assets\abcde.jpg")
        self.ctk_img1 = ctk.CTkImage(light_image=img1, dark_image=img1, size=(1920, 1080)) # Create CTkImage
        l1 = ctk.CTkLabel(master=self.login_frame, image=self.ctk_img1, text="") # Use CTkImage
        font=("Super Shiny", 14)
        l1.pack()

        # Create custom frame
        frame = ctk.CTkFrame(master=l1, width=320, height=420, corner_radius=15)
        frame.place(relx=0.5, rely=0.5, anchor=tkinter.CENTER)

        # Labels and Entry fields
        ctk.CTkLabel(master=frame, text="ShellExec", font=("a Area Stencil", 60)).grid(
        row=0, column=0, padx=(10, 5), pady=(10, 5), sticky="nsew", columnspan=2)

        # Hostname Label and Entry
        ctk.CTkLabel(master=frame, text="Hostname:", font=("Super Shiny", 30)).grid(row=1, column=0, padx=(10, 5), pady=(10, 5), sticky="e")
        self.hostname_entry = ctk.CTkEntry(master=frame, width=200, placeholder_text='Hostname', font=("Party Confetti", 20))
        self.hostname_entry.grid(row=1, column=1, padx=(0, 20), pady=(10, 5), sticky="w")

        # Username Label and Entry
        ctk.CTkLabel(master=frame, text="Username:", font=("Super Shiny", 30)).grid(row=2, column=0, padx=(10, 5), pady=(10, 5), sticky="e")
        self.username_entry = ctk.CTkEntry(master=frame, width=200, placeholder_text='Username', font=("Party Confetti", 20))
        self.username_entry.grid(row=2, column=1, padx=(0, 20), pady=(10, 5), sticky="w")

        # Password Label and Entry
        ctk.CTkLabel(master=frame, text="Password:", font=("Super Shiny", 30)).grid(row=3, column=0, padx=(10, 5), pady=(10, 5), sticky="e")
        self.password_entry = ctk.CTkEntry(master=frame, width=200, placeholder_text='Password', show="*", font=("Party Confetti", 20))
        self.password_entry.grid(row=3, column=1, padx=(0, 20), pady=(10, 5), sticky="w")

        # Create login button
        button1 = ctk.CTkButton(master=frame, width=220, text="Login", command=self.login_action, corner_radius=6, font=("Super Shiny", 28))
        button1.grid(row=4, column=0, columnspan=2, pady=(20, 10))  # Use grid to place the button


    def save_credentials(self, hostname, username, password):
        """Save credentials to a JSON file."""
        credentials = {
            "hostname": hostname,
            "username": username,
            "password": password
        }
        with open("credentials.json", "w") as file:
            json.dump(credentials, file)

    def load_credentials(self):
        """Load credentials from a JSON file."""
        if os.path.exists("credentials.json"):
            with open("credentials.json", "r") as file:
                credentials = json.load(file)
                self.hostname_entry.insert(0, credentials.get("hostname", ""))
                self.username_entry.insert(0, credentials.get("username", ""))
                self.password_entry.insert(0, credentials.get("password", ""))

    def login_action(self):
        """Handle login."""
        hostname = self.hostname_entry.get()
        username = self.username_entry.get()
        password = self.password_entry.get()

        if not hostname or not username or not password:
            messagebox.showerror("Error", "All fields are required.")
            return

        try:
            # Set up an SSH client
            self.ssh = paramiko.SSHClient()
            self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.ssh.connect(hostname=hostname, username=username, password=password)
            messagebox.showinfo("Success", "Login Successful!")

            # Save credentials after successful login
            self.save_credentials(hostname, username, password)

            # Switch to the main page
            self.login_frame.pack_forget()
            self.main_frame.pack(fill="both", expand=True)

        except paramiko.AuthenticationException:
            messagebox.showerror("Authentication Failed", "Invalid username or password.")
        except paramiko.SSHException as sshException:
            messagebox.showerror("SSH Error", f"Unable to establish SSH connection: {sshException}")
        except Exception as e:
            messagebox.showerror("Error", f"Unexpected error: {e}")

    def create_main_page(self):
        """Create the main page with organized script buttons."""
        title_label = ctk.CTkLabel(
            self.main_frame, text="ShellExec", font=("a Area Stencil", 24)
        )
        title_label.pack(side="left", anchor="n", padx=10, pady=20)

        # Create a frame for categories and scripts
        main_frame = ctk.CTkFrame(self.main_frame)
        main_frame.pack(expand=True, fill="both")

        # Create a frame for categories
        category_frame = ctk.CTkFrame(main_frame)
        category_frame.pack(side="left", fill="y", padx=10)

        # Create a frame for script buttons
        self.script_frame = ctk.CTkFrame(main_frame)
        self.script_frame.pack(side="right", fill="both", expand=True)

        # Define categories and corresponding scripts
        self.categories = {
            "Arithmetic": [
                "Addition",
                "Subtraction",
                "Multiplication",
                "Division",
                "Modulus",
                "Exponentiation",
                "Average of two numbers",
            ],
            "System Monitoring": [
                "Monitor memory usage",
                "Check disk usage for specific directory",
                "List processes by memory usage",
                "Show running processes",
            ],
            "File Management": [
                "New Directory",
                "Remove Directory",
                "List files in a directory",
                "Count files in a directory",
            ],
            "Log Management": [
                "Clear system logs",
                "Rotate logs manually",
                "Check recent logins",
                "Search logs for errors",
            ],
            "Networking": [
                "Show open ports",
                "Check internet connection",
                "Check DNS resolution",
                "Find IP address",
                "List active network connections",
            ],
            "Disk Management": [
                "List all partitions",
                "Check available disk space",
                "Check inode usage",
                "Find large files in a directory over 100mb",
                "Disk Partitions and Usage",
            ],
            "File Search and Cleanup": [
                "Find empty files",
                "List all symbolic links",
            ],
            "User and Group Management": [
                "List all users",
                "Check user group membership",
                "List all groups",
                "List all active user sessions",
                "Get user info",
            ],
            "Process Management": [
                "List all running processes",
                "Monitor system load",
                "Show process by CPU usage",
                "Show process by memory usage",
            ],
            "System Info": [
                "Show system uptime",
                "Show system architecture",
                "Show system hostname",
                "Show detailed system information",
                "Check all loaded kernel modules",
            ],
            "Miscellaneous": [
                "Display disk usage in human-readable format",
                "Count the number of directories in a path",
                "Display the last 10 lines of system log",
            ],
        }

        # Create category buttons
        for category in self.categories:
            button = ctk.CTkButton(
                category_frame,
                text=category,
                font=("Party Confetti", 16),
                command=lambda c=category: self.show_scripts(c, self.categories[c]),
            )
            button.pack(pady=5, fill='x')

        # Create a logout button at the bottom right
        logout_button = ctk.CTkButton(
            self.main_frame,
            text="Logout",
            font=("Super Shiny", 20),
            command=self.logout,
            fg_color="red",
        )
        logout_button.pack(side="bottom", anchor="se", padx=10, pady=10)

    def show_scripts(self, category, scripts):
        """Display scripts for the selected category."""
        # Clear the script frame
        for widget in self.script_frame.winfo_children():
            widget.destroy()

        title_label = ctk.CTkLabel(
            self.script_frame, text=f"{category} Scripts", font=("Party Confetti", 20)
        )
        title_label.pack(pady=20)

        # Create buttons for scripts in the selected category
        for title in scripts:
            button = ctk.CTkButton(
                self.script_frame,
                text=title,
                font=("Party Confetti", 16),
                command=lambda t=title: self.run_script_by_title(t),  # Pass the script title
            )
            button.pack(pady=5, fill='x')  # Fill horizontally

    def run_script_by_title(self, script_title):
        """Execute the selected script based on the button pressed."""
        # Map script titles to their corresponding script numbers
        script_mapping = {
            "Addition": 1,
            "Subtraction": 2,
            "Multiplication": 3,
            "Division": 4,
            "Modulus": 5,
            "Exponentiation": 6,
            "Average of two numbers": 7,

            "Monitor memory usage": 8,
            "Check disk usage for specific directory": 9,
            "List processes by memory usage": 10,
            "Show running processes": 11,

            "New Directory": 12,
            "Remove Directory": 13,
            "List files in a directory": 14,
            "Count files in a directory": 15,

            "Clear system logs": 16,
            "Rotate logs manually": 17,
            "Check recent logins": 18,
            "Search logs for errors": 19,

            "Show open ports": 20,
            "Check internet connection": 21,
            "Check DNS resolution": 22,
            "Find IP address": 23,
            "List active network connections": 24,

            "List all partitions": 25,
            "Check available disk space": 26,
            "Check inode usage": 27,
            "Find large files in a directory over 100mb": 28,
            "Disk Partitions and Usage": 29,

            "Find empty files": 30,
            "List all symbolic links": 31,

            "List all users": 32,
            "Check user group membership": 33,
            "List all groups": 34,
            "List all active user sessions": 35,
            "Get user info": 36,

            "List all running processes": 37,
            "Monitor system load": 38,
            "Show process by CPU usage": 39,
            "Show process by memory usage": 40,

            "Show system uptime": 41,
            "Show system architecture": 42,
            "Show system hostname": 43,
            "Show detailed system information": 44,
            "Check all loaded kernel modules": 45,

            "Display disk usage in human-readable format": 46,
            "Count the number of directories in a path": 47,
            "Display the last 10 lines of system log": 48,
        }

        script_number = script_mapping.get(script_title)
        if script_number:
            if script_number in [1, 2, 3, 4, 5, 6, 7]:
                # Scripts 1 to 7 require 2 inputs
                self.run_script_with_input(script_number, input_count=2)
            elif script_number in [12, 13]:
                # Scripts 12 and 13 require 1 input
                self.run_script_with_input(script_number, input_count=1)
            else:
                # For other scripts, execute directly without input
                script_path = f"/home/hxrrrshhh/scripts/script{script_number}.sh"
                self.execute_command(script_path)
        else:
            messagebox.showerror("Error", "Script not found.")

    def run_script_with_input(self, script_number, input_count):
        """Handle scripts that require user input."""
        inputs = []

        for i in range(input_count):
            user_input = self.get_user_input(f"Enter input {i + 1} for Script {script_number}:")
            if not user_input:
                messagebox.showerror("Error", f"Input {i + 1} is required to run Script {script_number}.")
                return
            inputs.append(user_input)

        # Construct the command with the script path and inputs
        script_path = f"/home/hxrrrshhh/scripts/script{script_number}.sh"
        self.execute_command(script_path, *inputs)

    def execute_command(self, script_path, *inputs):
        """Execute a script with the provided inputs."""
        if not self.ssh:
            messagebox.showerror("Error", "No SSH connection established.")
            return

        command = f"{script_path} {' '.join(inputs)}"
        try:
            stdin, stdout, stderr = self.ssh.exec_command(command)
            output = stdout.read().decode()
            error = stderr.read().decode()
            self.show_output(output, error)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to execute command: {e}")

    def show_output(self, output, error):
        """Display the output and error in a new window."""
        output_window = ctk.CTkToplevel(self.root)
        output_window.title("Command Output")
        output_window.geometry("600x400")
        output_window.wm_attributes("-topmost", 1)  # Make the window topmost

        text_widget = ctk.CTkTextbox(output_window, wrap="word")
        text_widget.pack(expand=True, fill="both", padx=10, pady=10)

        if output:
            text_widget.insert("end", "OUTPUT:\n" + output + "\n")
        if error:
            text_widget.insert("end", "ERROR:\n" + error + "\n")

        text_widget.configure(state="disabled")  # Make text read-only

    def get_user_input(self, prompt):
        """Get user input using a custom input dialog."""
        input_dialog = ctk.CTkToplevel(self.root)
        input_dialog.title("Input Required")
        input_dialog.geometry("300x200")
        input_dialog.wm_attributes("-topmost", 1)  # Make the dialog topmost

        label = ctk.CTkLabel(input_dialog, text=prompt)
        label.pack(pady=10)

        entry = ctk.CTkEntry(input_dialog)
        entry.pack(pady=10)

        def submit():
            self.user_input = entry.get()
            input_dialog.destroy()

        submit_button = ctk.CTkButton(input_dialog, text="Submit", command=submit)
        submit_button.pack(pady=10)

        input_dialog.wait_window(input_dialog)  # Wait for the dialog to close

        return getattr(self, 'user_input', None)

    def logout(self):
        """Handle logout."""
        if self.ssh:
            self.ssh.close()
            self.ssh = None
        self.main_frame.pack_forget()
        self.login_frame.pack(fill="both", expand=True)
        messagebox.showinfo("Logout", "You have been logged out.")


# Main program
if __name__ == "__main__":
    root = ctk.CTk()
    app = SSHApp(root)
    root.mainloop()